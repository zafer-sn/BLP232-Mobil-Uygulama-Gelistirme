package com.example.firebaseornek

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.firebaseornek.databinding.ActivityMainBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    private lateinit var gorunumBaglama: ActivityMainBinding
    private lateinit var firebase: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gorunumBaglama = ActivityMainBinding.inflate(layoutInflater)
        val gorunum = gorunumBaglama.root
        firebase = FirebaseDatabase.getInstance().reference
        enableEdgeToEdge()
        setContentView(gorunum)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Butona tıklandığında firebasea veri ekleme işlemi
        gorunumBaglama.button.setOnClickListener {
            var k1 = Kullanici(
                gorunumBaglama.idText.text.toString().toInt(),
                gorunumBaglama.kullaniciAdiText.text.toString(),
                gorunumBaglama.parolaTextPassword.text.toString()
            )
            firebase.setValue(k1)
        }

    }
}