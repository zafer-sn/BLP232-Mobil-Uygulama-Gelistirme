package com.example.firebaseornek

data class Kullanici(
    var id: Int,
    var kullaniciAdi: String,
    var parola: String
)
